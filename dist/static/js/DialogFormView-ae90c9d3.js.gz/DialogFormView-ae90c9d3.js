import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-d79ca6d2.js";import"./index-fe0b5c08.js";export{m as default};
