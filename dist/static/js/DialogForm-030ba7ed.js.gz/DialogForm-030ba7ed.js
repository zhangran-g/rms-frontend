import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-3806e0ef.js";import"./message-5fe7bad9.js";import"./index-0b96d5f9.js";export{o as default};
