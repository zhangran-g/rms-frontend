import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-c9fb84f8.js";import"./message-b5bc3fc0.js";import"./index-fe0b5c08.js";export{o as default};
