import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-bea51811.js";import"./index-5cfd3186.js";export{m as default};
