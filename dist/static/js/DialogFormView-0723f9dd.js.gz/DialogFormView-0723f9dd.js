import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-259c1831.js";import"./index-e73d59d1.js";export{m as default};
