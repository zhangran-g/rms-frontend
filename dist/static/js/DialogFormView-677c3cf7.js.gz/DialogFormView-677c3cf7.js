import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-d096577d.js";import"./index-e6c3427c.js";export{m as default};
