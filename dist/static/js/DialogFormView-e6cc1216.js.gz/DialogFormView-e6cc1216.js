import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-33279387.js";import"./index-35996766.js";export{m as default};
