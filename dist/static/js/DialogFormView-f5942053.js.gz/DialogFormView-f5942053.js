import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-2a88bb1a.js";import"./index-ac7d7e69.js";export{m as default};
