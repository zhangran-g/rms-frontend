import{ay as r}from"./index-0b96d5f9.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
