import{ay as r}from"./index-e73d59d1.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
