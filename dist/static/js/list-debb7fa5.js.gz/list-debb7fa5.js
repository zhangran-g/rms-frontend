import{ay as r}from"./index-35996766.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
