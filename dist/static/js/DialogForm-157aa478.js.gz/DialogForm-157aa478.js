import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-dd193ae9.js";import"./message-cd8495f4.js";import"./index-4f32348e.js";export{o as default};
