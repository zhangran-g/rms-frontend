import{ay as r}from"./index-4f32348e.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
