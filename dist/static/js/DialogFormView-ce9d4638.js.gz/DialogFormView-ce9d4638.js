import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-f762dc3c.js";import"./index-4f32348e.js";export{m as default};
