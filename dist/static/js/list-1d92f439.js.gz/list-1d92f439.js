import{ay as r}from"./index-fe0b5c08.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
