import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-a3b53b5c.js";import"./message-bae22f01.js";import"./index-432e9045.js";export{o as default};
