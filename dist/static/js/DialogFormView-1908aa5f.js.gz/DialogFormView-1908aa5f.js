import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-a87b5542.js";import"./index-432e9045.js";export{m as default};
