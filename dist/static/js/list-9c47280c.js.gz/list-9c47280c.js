import{ay as r}from"./index-432e9045.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
