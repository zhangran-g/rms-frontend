import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-eada7c4c.js";import"./message-37fb096c.js";import"./index-e73d59d1.js";export{o as default};
