import{ay as r}from"./index-e6c3427c.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
