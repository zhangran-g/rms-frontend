import{ay as r}from"./index-5cfd3186.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
