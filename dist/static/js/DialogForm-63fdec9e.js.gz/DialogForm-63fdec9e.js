import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-4d014b92.js";import"./message-25da8e5e.js";import"./index-ac7d7e69.js";export{o as default};
