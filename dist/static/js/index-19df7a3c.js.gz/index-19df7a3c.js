import{d as e,o,c as t}from"./index-35996766.js";const c=e({name:"Welcome"}),r=e({...c,setup(n){return(a,_)=>(o(),t("h1",null,"Welcome！"))}});export{r as default};
